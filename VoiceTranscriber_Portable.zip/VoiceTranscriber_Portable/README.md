# Local Voice Transcriber

A simple desktop application for recording voice and transcribing it using OpenAI Whisper.

## Features
- Record audio from microphone
- Real-time audio level visualization
- Local transcription using Whisper (no internet required)
- Save transcriptions with datetime stamps
- Windows executable support

## Setup
1. Create virtual environment: `python -m venv venv`
2. Activate: `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (Mac/Linux)
3. Install dependencies: `pip install -r requirements.txt`
4. Run: `python main.py`

## Building Executable
`pyinstaller --onefile --windowed main.py`