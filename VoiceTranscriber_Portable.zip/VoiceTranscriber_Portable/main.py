import sys
import os
import threading
import queue
from datetime import datetime
import numpy as np
import sounddevice as sd
import whisper
from scipy.io.wavfile import write
import tempfile
from PyQt6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
                           QWidget, QPushButton, QTextEdit, QLabel, QProgressBar,
                           QFileDialog, QComboBox, QGroupBox)
from PyQt6.QtCore import QTimer, QThread, pyqtSignal, Qt
from PyQt6.QtGui import QFont, QPalette, QColor


class AudioLevelMeter(QWidget):
    def __init__(self):
        super().__init__()
        self.level = 0
        self.setFixedSize(200, 30)
    
    def paintEvent(self, event):
        from PyQt6.QtGui import QPainter, QBrush
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Background
        painter.fillRect(self.rect(), QColor(50, 50, 50))
        
        # Level bar
        width = int(self.width() * self.level)
        if width > 0:
            color = QColor(0, 255, 0) if self.level < 0.8 else QColor(255, 255, 0) if self.level < 0.9 else QColor(255, 0, 0)
            painter.fillRect(0, 0, width, self.height(), color)
    
    def update_level(self, level):
        self.level = max(0, min(1, level))
        self.update()


class TranscriptionWorker(QThread):
    transcription_ready = pyqtSignal(str)
    progress_update = pyqtSignal(int)
    
    def __init__(self, audio_data, sample_rate):
        super().__init__()
        self.audio_data = audio_data
        self.sample_rate = sample_rate
        self.model = None
    
    def run(self):
        try:
            self.progress_update.emit(20)
            if self.model is None:
                self.model = whisper.load_model("base")
            
            self.progress_update.emit(50)
            
            # Convert audio data to the format Whisper expects
            # Whisper expects float32 audio normalized to [-1, 1]
            if self.audio_data.dtype != np.float32:
                if self.audio_data.dtype == np.int16:
                    audio_float = self.audio_data.astype(np.float32) / 32768.0
                elif self.audio_data.dtype == np.int32:
                    audio_float = self.audio_data.astype(np.float32) / 2147483648.0
                else:
                    audio_float = self.audio_data.astype(np.float32)
            else:
                audio_float = self.audio_data
            
            # Flatten if stereo
            if len(audio_float.shape) > 1:
                audio_float = np.mean(audio_float, axis=1)
            
            # Resample to 16kHz if needed (Whisper's expected sample rate)
            if self.sample_rate != 16000:
                # Simple resampling
                import scipy.signal
                num_samples = int(len(audio_float) * 16000 / self.sample_rate)
                audio_float = scipy.signal.resample(audio_float, num_samples)
            
            self.progress_update.emit(80)
            
            # Transcribe directly from numpy array (no file needed!)
            result = self.model.transcribe(audio_float)
            
            self.progress_update.emit(100)
            self.transcription_ready.emit(result["text"])
        except Exception as e:
            self.transcription_ready.emit(f"Error during transcription: {str(e)}")


class VoiceTranscriberApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.recording = False
        self.recorded_data = []
        self.sample_rate = 44100
        self.output_directory = os.path.expanduser("~/Documents")
        self.audio_queue = queue.Queue()
        self.transcription_worker = None
        
        self.init_ui()
        self.init_audio()
        
        # Timer for audio level updates
        self.level_timer = QTimer()
        self.level_timer.timeout.connect(self.update_audio_level)
        
    def init_ui(self):
        self.setWindowTitle("Local Voice Transcriber")
        self.setGeometry(100, 100, 600, 500)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # Title
        title = QLabel("Voice Transcriber")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont("Arial", 18, QFont.Weight.Bold))
        layout.addWidget(title)
        
        # Microphone selection
        mic_group = QGroupBox("Microphone")
        mic_layout = QVBoxLayout(mic_group)
        
        self.mic_combo = QComboBox()
        self.populate_microphones()
        mic_layout.addWidget(self.mic_combo)
        layout.addWidget(mic_group)
        
        # Audio level meter
        level_group = QGroupBox("Audio Level")
        level_layout = QVBoxLayout(level_group)
        self.audio_meter = AudioLevelMeter()
        level_layout.addWidget(self.audio_meter)
        layout.addWidget(level_group)
        
        # Control buttons
        button_layout = QHBoxLayout()
        
        self.record_button = QPushButton("🎤 Start Recording")
        self.record_button.setFont(QFont("Arial", 12))
        self.record_button.setFixedHeight(50)
        self.record_button.clicked.connect(self.toggle_recording)
        button_layout.addWidget(self.record_button)
        
        self.output_button = QPushButton("📁 Select Output Folder")
        self.output_button.setFont(QFont("Arial", 10))
        self.output_button.setFixedHeight(50)
        self.output_button.clicked.connect(self.select_output_directory)
        button_layout.addWidget(self.output_button)
        
        layout.addLayout(button_layout)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel(f"Ready to record. Output: {self.output_directory}")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        
        # Transcription display
        transcription_group = QGroupBox("Transcription")
        transcription_layout = QVBoxLayout(transcription_group)
        
        self.transcription_text = QTextEdit()
        self.transcription_text.setFont(QFont("Arial", 11))
        self.transcription_text.setPlaceholderText("Transcription will appear here...")
        transcription_layout.addWidget(self.transcription_text)
        
        layout.addWidget(transcription_group)
        
        # Set style
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QGroupBox {
                font-weight: bold;
                margin-top: 6px;
                padding: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """)
    
    def init_audio(self):
        try:
            self.devices = sd.query_devices()
            self.input_devices = [i for i, device in enumerate(self.devices) 
                                if device['max_input_channels'] > 0]
        except Exception as e:
            self.status_label.setText(f"Audio initialization error: {e}")
    
    def populate_microphones(self):
        try:
            devices = sd.query_devices()
            self.mic_combo.clear()
            for i, device in enumerate(devices):
                if device['max_input_channels'] > 0:
                    self.mic_combo.addItem(f"{device['name']} (Device {i})", i)
        except Exception as e:
            self.mic_combo.addItem("No microphones found", -1)
    
    def select_output_directory(self):
        directory = QFileDialog.getExistingDirectory(
            self, "Select Output Directory", self.output_directory)
        if directory:
            self.output_directory = directory
            self.status_label.setText(f"Ready to record. Output: {self.output_directory}")
    
    def toggle_recording(self):
        if not self.recording:
            self.start_recording()
        else:
            self.stop_recording()
    
    def start_recording(self):
        try:
            device_index = self.mic_combo.currentData()
            if device_index == -1:
                self.status_label.setText("No microphone selected")
                return
            
            self.recording = True
            self.recorded_data = []
            self.record_button.setText("⏹️ Stop Recording")
            self.record_button.setStyleSheet("background-color: #f44336;")
            self.status_label.setText("Recording... Speak now!")
            
            # Start recording stream
            self.stream = sd.InputStream(
                device=device_index,
                channels=1,
                samplerate=self.sample_rate,
                callback=self.audio_callback
            )
            self.stream.start()
            
            # Start level monitoring
            self.level_timer.start(50)  # Update every 50ms
            
        except Exception as e:
            self.status_label.setText(f"Recording error: {e}")
            self.recording = False
    
    def audio_callback(self, indata, frames, time, status):
        if status:
            print(f"Audio callback status: {status}")
        
        # Store audio data
        self.recorded_data.append(indata.copy())
        
        # Update level meter
        volume_norm = np.linalg.norm(indata) * 10
        self.audio_queue.put(volume_norm)
    
    def update_audio_level(self):
        try:
            while True:
                level = self.audio_queue.get_nowait()
                self.audio_meter.update_level(level)
        except queue.Empty:
            pass
    
    def stop_recording(self):
        if not self.recording:
            return
        
        try:
            self.recording = False
            self.level_timer.stop()
            self.stream.stop()
            self.stream.close()
            
            self.record_button.setText("🎤 Start Recording")
            self.record_button.setStyleSheet("background-color: #4CAF50;")
            self.status_label.setText("Processing audio...")
            
            # Save audio file
            if self.recorded_data:
                audio_data = np.concatenate(self.recorded_data, axis=0)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                
                # Use temp file for transcription (avoids path issues)
                temp_audio = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
                write(temp_audio.name, self.sample_rate, audio_data)
                temp_audio.close()
                
                # Also save to user's directory
                audio_filename = f"{timestamp}.wav"
                audio_path = os.path.join(self.output_directory, audio_filename)
                write(audio_path, self.sample_rate, audio_data)
                
                # Start transcription using audio data directly (no file needed)
                self.progress_bar.setVisible(True)
                self.progress_bar.setValue(0)
                
                self.transcription_worker = TranscriptionWorker(audio_data, self.sample_rate)
                self.transcription_worker.transcription_ready.connect(self.on_transcription_ready)
                self.transcription_worker.progress_update.connect(self.progress_bar.setValue)
                self.transcription_worker.start()
            else:
                self.status_label.setText("No audio recorded")
                
        except Exception as e:
            self.status_label.setText(f"Error stopping recording: {e}")
    
    def on_transcription_ready(self, text):
        self.progress_bar.setVisible(False)
        self.transcription_text.setPlainText(text)
        
        # Save transcription to file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        text_filename = f"{timestamp}.txt"
        text_path = os.path.join(self.output_directory, text_filename)
        
        try:
            with open(text_path, 'w', encoding='utf-8') as f:
                f.write(text)
            self.status_label.setText(f"Transcription saved: {text_filename}")
        except Exception as e:
            self.status_label.setText(f"Error saving transcription: {e}")
    
    def closeEvent(self, event):
        if self.recording:
            self.stop_recording()
        event.accept()


def main():
    app = QApplication(sys.argv)
    
    # Set application properties
    app.setApplicationName("Voice Transcriber")
    app.setApplicationVersion("1.0")
    
    window = VoiceTranscriberApp()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()