# Voice Transcriber - Usage Instructions

## Quick Start

### To Run the App Directly:
- **Mac/Linux**: `./run.sh`
- **Windows**: Double-click `run.bat` or type `run.bat` in Command Prompt
- **Any OS**: `python main.py` (after activating virtual environment)

### To Build Windows Executable:
1. Transfer this folder to a Windows computer
2. Double-click `build_windows.bat` OR open Command Prompt and run `build_windows.bat`
3. The executable will be created in the `dist/` folder as `VoiceTranscriber.exe`
4. Distribute `VoiceTranscriber.exe` - it's a standalone file that doesn't need Python

## File Types Explained:
- **`.py`** = Python source code
- **`.bat`** = Windows batch script (double-clickable on Windows)
- **`.sh`** = Shell script (executable on Mac/Linux)
- **`.exe`** = Windows executable (created by PyInstaller)

## App Features:
- 🎤 Record voice with visual audio level feedback
- 📝 Automatic transcription using Whisper AI (offline)
- 💾 Save transcriptions as datetime-stamped .txt files
- 📁 Choose output folder
- 🔧 Automatic microphone detection

## First Time Setup (if needed):
```bash
python -m venv venv
source venv/bin/activate  # Mac/Linux
# OR
venv\Scripts\activate.bat  # Windows
pip install -r requirements.txt
```