# Portable Voice Transcriber

## First Time Setup:
1. Extract this folder anywhere on your computer
2. Double-click "SETUP.bat" and wait for it to complete (5-10 minutes)

## To Use:
- Double-click "VoiceTranscriber.bat" to start the app

## To Create Standalone EXE (Optional):
- Double-click "BUILD_EXE.bat" after setup
- Creates VoiceTranscriber.exe in dist/ folder
- Share just the .exe file (no setup needed for recipients)

## What's Included:
- Portable Python (no installation needed)
- Voice Transcriber application
- Whisper AI for offline transcription
- All required libraries

## System Requirements:
- Windows 10/11 (64-bit)
- ~500MB disk space
- Microphone

No Python installation required!