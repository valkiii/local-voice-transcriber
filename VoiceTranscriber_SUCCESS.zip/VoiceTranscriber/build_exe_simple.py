import os
import subprocess
import whisper as whisper_lib

print("Building EXE with Whisper model...")

# Download model
print("Downloading Whisper model...")
model = whisper_lib.load_model("base")
cache_dir = os.path.expanduser("~/.cache/whisper")

# Build with PyInstaller
print("Installing PyInstaller...")
subprocess.run([
    "python\\python.exe", "-m", "pip", "install", "--target", "python", "pyinstaller"
], check=True)

print("Building executable...")
cmd = [
    "python\\python.exe", "-m", "PyInstaller",
    "--onefile", "--windowed", "--name=VoiceTranscriber",
    f"--add-data={cache_dir};whisper_cache",
    "--collect-all=whisper", "--collect-all=torch", "--collect-all=sounddevice",
    "--collect-all=scipy", "--collect-all=numpy", "--collect-all=PyQt6",
    "main.py"
]

try:
    result = subprocess.run(cmd)
    if os.path.exists("dist/VoiceTranscriber.exe"):
        size = os.path.getsize("dist/VoiceTranscriber.exe") / (1024 * 1024)
        print(f"\nSUCCESS! VoiceTranscriber.exe created ({size:.1f} MB)")
        print("File: dist/VoiceTranscriber.exe")
        print("Ready to share - includes Whisper model!")
    else:
        print("Build completed but exe not found in expected location")
except Exception as e:
    print(f"Build error: {e}")