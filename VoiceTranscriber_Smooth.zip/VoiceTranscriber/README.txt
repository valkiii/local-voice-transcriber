Voice Transcriber - Smooth Purple Neon

✨ PERFECTED DESIGN:
🖤 True dark background
💜 Purple neon theme
🎤 Smaller ball (stays within bounds)
🌊 Smooth, slower animations
📝 Selectable/copyable text (no visible box)
💾 Saves only .txt files

🎯 USAGE:
- Click purple ball to record
- Ball smoothly pulses with voice
- Select/copy transcription text
- Ctrl+A to select all, Ctrl+C to copy